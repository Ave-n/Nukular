# Particle-Life
A game of life with particles: https://youtu.be/Z_zmZ23grXE
